CKEDITOR.plugins.setLang( 'html5video', 'zh-cn', {
    button: '插入 HTML5 视频',
    title: 'HTML5 视频',
    infoLabel: '视频信息',
    allowed: '允许的视频文件: MP4, WebM, Ogv...',
    urlMissing: '视频URL地址缺失.',
    videoProperties: '视频属性',
    upload: '上传',
    btnUpload: '上传到服务器',
    advanced: '高级',
    autoplay: '自动播放?',
    yes: '是',
    no: '否',
	responsive: '自动响应宽度'
} );
